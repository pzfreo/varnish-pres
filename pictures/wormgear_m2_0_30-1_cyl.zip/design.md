# Worm Gear Design

## Worm
- Module: 2.000 mm
- Starts: 1
- Pitch Diameter: 16.000 mm
- Lead: 6.283 mm
- Lead Angle: 7.13°

## Wheel
- Teeth: 30
- Pitch Diameter: 60.000 mm
- Tip Diameter: 64.000 mm

## Assembly
- Centre Distance: 38.000 mm
- Ratio: 1:30
- Hand: right
